
#     engine.say(audio)
#     engine.runAndWait()